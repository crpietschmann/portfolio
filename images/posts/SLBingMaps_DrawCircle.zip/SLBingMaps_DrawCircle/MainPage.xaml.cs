﻿using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Maps.MapControl;

namespace SLBingMaps_DrawCircle
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Map_MouseClick(object sender, Microsoft.Maps.MapControl.MapMouseEventArgs e)
        {
            // Get the location the mouse clicked
            var mousePoint = e.ViewportPoint;
            var clickedLocation = MainMap.ViewportPointToLocation(mousePoint);

            // Calculate the points to make up a circle with radius of 200 miles
            var locations = GeoCodeCalc.CreateCircle(clickedLocation, 200, DistanceMeasure.Miles);

            // Add Red Polyline to the Map
            var poly = new MapPolyline();
            poly.Locations = locations;
            poly.Stroke = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));
            poly.StrokeThickness = 2;
            MainMap.Children.Add(poly);            
        }
    }
}
