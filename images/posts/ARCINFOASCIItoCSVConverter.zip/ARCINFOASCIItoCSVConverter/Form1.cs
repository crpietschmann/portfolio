﻿// Copyright (c) 2007 Chris Pietschmann (http://pietschsoft.com)
// Originally Posted Here:
// http://pietschsoft.com/post/2008/06/Plot-ZipCode-Boundaries-on-a-Map-Part1-Making-sense-of-US-Census-ZCTA-ARCINFO-Ungenerate-ASCII-files.aspx

using System;
using System.Windows.Forms;
using System.IO;

namespace ImportCencus2000ARCINFOASCII
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            if (file.ShowDialog() == DialogResult.OK)
            {
                this.ConvertZipCodeFileToCSV(file.FileName, file.FileName + ".csv");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            if (file.ShowDialog() == DialogResult.OK)
            {
                this.ConvertZipCodeBoundaryFileToCSV(file.FileName, file.FileName + ".csv");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fd = new FolderBrowserDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                // Convert All Files in Folder
                string[] files = Directory.GetFiles(fd.SelectedPath);

                toolStripProgress.Maximum = files.Length + 1;
                toolStripProgress.Minimum = 0;
                toolStripProgress.Value = 0;

                string savePath = fd.SelectedPath + "\\CSV\\";

                Directory.CreateDirectory(savePath);

                string filename = "";
                string path = "";

                foreach (string filepath in files)
                {
                    filename = filepath.Substring(filepath.LastIndexOf("\\") + 1);
                    path = filepath.Substring(0, filepath.LastIndexOf("\\") + 1);

                    toolStripStatus.Text = "Converting File " + filename + "...";
                    Application.DoEvents();

                    if (filepath.ToLowerInvariant().EndsWith("a.dat"))
                    {
                        this.ConvertZipCodeFileToCSV(filepath, savePath + filename + ".csv");
                    }
                    else if (filepath.ToLowerInvariant().EndsWith(".dat"))
                    {
                        this.ConvertZipCodeBoundaryFileToCSV(filepath, savePath + filename + ".csv");
                    }
                    toolStripProgress.Value++;
                }
                toolStripProgress.Value = toolStripProgress.Maximum;
                toolStripStatus.Text = "All Files Converted Successfully";
                MessageBox.Show("All *a.dat and *.dat files have been converted to CSV format.", "Conversion Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ConvertZipCodeBoundaryFileToCSV(string openFileName, string saveFileName)
        {
            FileStream f = new FileStream(openFileName, FileMode.Open);
            StreamReader reader = new StreamReader(f);

            FileStream csvfile = new FileStream(saveFileName, FileMode.Create);
            StreamWriter writer = new StreamWriter(csvfile);
            writer.WriteLine("ZipID,IslandId,LATITUDE,LONGITUDE,SortOrder");

            string strLine;
            string strID = "";
            int sortOrder = -1;
            string strCSVLine = "";

            bool IsIsland = false;
            int IslandId = 0;

            while (!reader.EndOfStream)
            {
                strLine = reader.ReadLine();

                sortOrder++;

                if (strLine.Length == 66)
                {
                    strID = strLine.Substring(0, 10).Trim();
                    sortOrder = 0;
                    writer.WriteLine("" +
                        strID +
                        "," +
                        (IsIsland ? IslandId.ToString() : "") +
                        "," +
                        double.Parse(strLine.Substring(10, 28).Trim()).ToString() +
                        "," +
                        double.Parse(strLine.Substring(38).Trim()).ToString() +
                        "," +
                        sortOrder.ToString()
                        );
                }
                else if (strLine.Length == 56)
                {
                    writer.WriteLine("" +
                        strID +
                        "," +
                        (IsIsland ? IslandId.ToString() : "") +
                        "," +
                        double.Parse(strLine.Substring(0, 28).Trim()).ToString() +
                        "," +
                        double.Parse(strLine.Substring(28).Trim()).ToString() +
                        "," +
                        sortOrder.ToString()
                        );
                }
                else if (strLine.Length == 10)
                {
                    IsIsland = true;
                    sortOrder = -1;
                    IslandId++;
                }
                else
                {
                    // Don't Write This Line
                    IsIsland = false;
                }
            }
            if (!string.IsNullOrEmpty(strCSVLine))
            {
                writer.WriteLine(strCSVLine);
            }

            reader.Close();
            f.Dispose();
            reader.Dispose();

            writer.Close();
            csvfile.Dispose();
            writer.Dispose();
        }

        private void ConvertZipCodeFileToCSV(string openFileName, string saveFileName)
        {
            FileStream f = new FileStream(openFileName, FileMode.Open);
            StreamReader reader = new StreamReader(f);

            FileStream csvfile = new FileStream(saveFileName, FileMode.Create);
            StreamWriter writer = new StreamWriter(csvfile);
            writer.WriteLine("ZipID,FIPS CODES(S),NAME,LSAD,LSAD TRANSLATION");

            string strLine;
            string strCSVLine = "";
            while (!reader.EndOfStream)
            {
                strLine = reader.ReadLine();

                if (strLine == " ")
                {
                    writer.WriteLine(strCSVLine);
                    strCSVLine = "";
                }
                else
                {
                    if (!string.IsNullOrEmpty(strCSVLine)) strCSVLine += ",";
                    strCSVLine += strLine.Trim().Replace("\"", "");
                }

            }
            if (!string.IsNullOrEmpty(strCSVLine))
            {
                writer.WriteLine(strCSVLine);
            }

            reader.Close();
            f.Dispose();
            reader.Dispose();

            writer.Close();
            csvfile.Dispose();
            writer.Dispose();
        }
    }
}
