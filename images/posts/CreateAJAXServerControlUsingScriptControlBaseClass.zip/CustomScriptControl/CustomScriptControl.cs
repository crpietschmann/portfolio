﻿// Copyright (c) Chris Pietschmann 2008. All rights reserved.
// This work is licensed under a Creative Commons Attribution 3.0 United States License (http://creativecommons.org/licenses/by/3.0/us/)
// Originally posted at: http://pietschsoft.com/post/2008/05/ASPNET_Create_AJAX_Server_Controls_using_the_ScriptControl_base_class.aspx
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

[assembly: System.Web.UI.WebResource("CustomScriptControl.CustomScriptControl.js", "text/javascript")]

namespace CustomScriptControl
{
    [ScriptReference("CustomScriptControl.CustomScriptControl.js", "CustomScriptControl")]
    public class CustomScriptControl : ScriptControlBase
    {
        [ScriptControlProperty]
        public string Name { get; set; }
    }
}
