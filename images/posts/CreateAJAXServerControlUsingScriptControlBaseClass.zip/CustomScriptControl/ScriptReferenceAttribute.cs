﻿// Copyright (c) Chris Pietschmann 2008. All rights reserved.
// This work is licensed under a Creative Commons Attribution 3.0 United States License (http://creativecommons.org/licenses/by/3.0/us/)
// Originally posted at: http://pietschsoft.com/post/2008/05/ASPNET_Create_AJAX_Server_Controls_using_the_ScriptControl_base_class.aspx
using System;
using System.Web.UI;

namespace CustomScriptControl
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class ScriptReferenceAttribute : Attribute
    {
        public ScriptReferenceAttribute(string path)
        {
            this.Path = path;
        }

        public ScriptReferenceAttribute(string name, string assembly)
        {
            this.Name = name;
            this.Assembly = assembly;
        }

        private string _path = null;
        public string Path
        {
            get { return _path; }
            set { _path = value; }
        }

        private string _name = null;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _assembly = null;
        public string Assembly
        {
            get { return _assembly; }
            set { _assembly = value; }
        }

        public ScriptReference GetScriptReference()
        {
            ScriptReference r = null;

            if (this.Path == null)
            {
                r = new ScriptReference(this.Name, this.Assembly);
            }
            else
            {
                r = new ScriptReference(this.Path);
            }

            return r;
        }
    }
}
