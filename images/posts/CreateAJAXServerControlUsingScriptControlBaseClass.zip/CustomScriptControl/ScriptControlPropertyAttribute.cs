﻿// Copyright (c) Chris Pietschmann 2008. All rights reserved.
// This work is licensed under a Creative Commons Attribution 3.0 United States License (http://creativecommons.org/licenses/by/3.0/us/)
// Originally posted at: http://pietschsoft.com/post/2008/05/ASPNET_Create_AJAX_Server_Controls_using_the_ScriptControl_base_class.aspx
using System;

namespace CustomScriptControl
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class ScriptControlPropertyAttribute : Attribute
    {
        public ScriptControlPropertyAttribute() { }

        public ScriptControlPropertyAttribute(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }
    }
}
