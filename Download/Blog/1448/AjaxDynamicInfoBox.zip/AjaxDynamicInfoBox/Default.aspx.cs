﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.Services;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /// This is our Page Method that we'll use in the page to load
    /// the Title and Description of teh Shapes' InfoBox
    [WebMethod]
    public static InfoBoxData GetInfoBoxData(int id)
    {
        // Pass back the InfoBoxData
        InfoBoxData data = new InfoBoxData();
        data.Title = "Item " + id.ToString();

        // Get the HTML to be displayed within the Description field
        data.Description = ViewManager.RenderView("~/App_Views/InfoBoxDescription.ascx", id);

        return data;
    }

    /// This is our objct that we'll use to pass down the InfoBox Data to
    /// the page in the GetInfoBoxData Page Method
    public class InfoBoxData
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
