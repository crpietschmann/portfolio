// README
//
// There are two steps to adding a property:
//
// 1. Create a member variable to store your property
// 2. Add the get_ and set_ accessors for your property.
//
// Remember that both are case sensitive!
//

Type.registerNamespace('GenericJSONTypeConverter');

GenericJSONTypeConverter.GenericJSONTypeConverterBehavior = function(element) {

    GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.initializeBase(this, [element]);

    // TODO : (Step 1) Add your property variables here
    //
    this._myPersonValue = null;

}

GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.prototype = {

    initialize : function() {
        GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.callBaseMethod(this, 'initialize');

        // TODO: add your initalization code here
        if(this._myPersonValue!=null)
        {
            this._myPersonValue=Sys.Serialization.JavaScriptSerializer.deserialize(this._myPersonValue);
        }
        
        alert("The full name of my person is:\n"
            + this._myPersonValue.FirstName + " " + this._myPersonValue.LastName);
    },

    dispose : function() {
        // TODO: add your cleanup code here

        GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.callBaseMethod(this, 'dispose');
    },

    // TODO: (Step 2) Add your property accessors here
    //
    get_MyPerson : function() {
        return this._myPersonValue;
    },

    set_MyPerson : function(value) {
        this._myPersonValue = value;
    }
}

GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.registerClass('GenericJSONTypeConverter.GenericJSONTypeConverterBehavior', AjaxControlToolkit.BehaviorBase);
