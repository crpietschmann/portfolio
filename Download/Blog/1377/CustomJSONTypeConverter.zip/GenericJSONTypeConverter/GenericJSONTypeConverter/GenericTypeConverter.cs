using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Web.Script.Serialization;

namespace GenericJSONTypeConverter
{
    public class GenericTypeConverter : TypeConverter
    {
        public override object ConvertTo(ITypeDescriptorContext context,
            System.Globalization.CultureInfo culture,
            object value, Type destinationType)
        {
            JavaScriptSerializer jss = new JavaScriptSerializer();
            string s = jss.Serialize(value);
            return s;
        }
    }
}
