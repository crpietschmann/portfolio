using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace GenericJSONTypeConverter
{
    [TypeConverter(typeof(GenericTypeConverter))]
    public class Person
    {
        private string _FirstName;
        public string FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }

        private string _LastName;
        public string LastName
        {
            get { return _LastName; }
            set { _LastName = value; }
        }
    }

}
