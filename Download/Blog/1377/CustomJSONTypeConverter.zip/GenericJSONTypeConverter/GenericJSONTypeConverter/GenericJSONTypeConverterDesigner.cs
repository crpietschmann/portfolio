using System.Web.UI.WebControls;
using System.Web.UI;

namespace GenericJSONTypeConverter
{
    class GenericJSONTypeConverterDesigner : AjaxControlToolkit.Design.ExtenderControlBaseDesigner<GenericJSONTypeConverterExtender>
    {


    }
}
