using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;
using System.ComponentModel.Design;
using AjaxControlToolkit;

[assembly: System.Web.UI.WebResource("GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.js", "text/javascript")]

namespace GenericJSONTypeConverter
{
    [Designer(typeof(GenericJSONTypeConverterDesigner))]
    [ClientScriptResource("GenericJSONTypeConverter.GenericJSONTypeConverterBehavior", "GenericJSONTypeConverter.GenericJSONTypeConverterBehavior.js")]
    [TargetControlType(typeof(Control))]
    public class GenericJSONTypeConverterExtender : ExtenderControlBase
    {
        // TODO: Add your property accessors here.
        //
        private Person _MyPerson;
        [ExtenderControlProperty]
        public Person MyPerson
        {
            get
            {
                return _MyPerson;
            }
            set
            {
                _MyPerson = value;
            }
        }
    }
}
