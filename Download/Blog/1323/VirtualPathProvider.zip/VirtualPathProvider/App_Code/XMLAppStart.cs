using System.Web.Hosting;

/// <summary>
/// Summary description for XMLAppStart
/// </summary>
public static class XMLAppStart
{
    public static void AppInitialize()
    {
        XMLPathProvider sampleProvider = new XMLPathProvider();
        HostingEnvironment.RegisterVirtualPathProvider(sampleProvider);
    } 
}
