﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Silverlight_BingMaps_with_ChildWindow
{
    public partial class BasicPushpin : UserControl
    {
        public BasicPushpin()
        {
            InitializeComponent();

            this.ID = Guid.NewGuid().ToString();
        }

        public string ID { get; set; }

        public StackPanel TooltipPanel
        {
            get
            {
                return stackPanelTooltip;
            }
        }

        public void ShowEditDialog()
        {
            var tooltip = this.TooltipPanel.Children[0] as BasicTooltip;

            var dlg = new BasicEditDialog();
            dlg.txtTitle.Text = tooltip.txtTitle.Text;
            dlg.txtDescription.Text = tooltip.txtDescription.Text;
            dlg.Closed += new EventHandler(dlg_Closed);
            dlg.Show();
        }

        void dlg_Closed(object sender, EventArgs e)
        {
            var dlg = sender as BasicEditDialog;
            if (dlg.DialogResult == true)
            {
                var tooltip = this.TooltipPanel.Children[0] as BasicTooltip;
                tooltip.txtTitle.Text = dlg.txtTitle.Text;
                tooltip.txtDescription.Text = dlg.txtDescription.Text;
            }
        }

        private void UserControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ShowEditDialog();
            e.Handled = true;
        }
    }
}
