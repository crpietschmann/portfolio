﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VirtualEarth.MapControl;

namespace Silverlight_BingMaps_with_ChildWindow
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private MapLayer pushpinLayer = null;

        private void Map_MouseClick(object sender, Microsoft.VirtualEarth.MapControl.MapMouseEventArgs e)
        {
            var map = (Map)sender;
            
            var location = map.ViewportPointToLocation(e.ViewportPoint);

            if (pushpinLayer == null)
            {
                pushpinLayer = new MapLayer();

                map.AddChild(pushpinLayer);
            }

            var pushpin = new BasicPushpin();

            var tooltip = new BasicTooltip();
            tooltip.txtTitle.Text = "Basic Pushpin";
            tooltip.txtDescription.Text = 
                    "Lat: " + location.Latitude.ToString() + Environment.NewLine +
                    "Lng: " + location.Longitude.ToString();
            pushpin.TooltipPanel.Children.Add(tooltip);


            var position = PositionMethod.Center;

            pushpinLayer.AddChild(pushpin, location, position);

            pushpin.ShowEditDialog();
        }
    }
}
