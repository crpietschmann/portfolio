﻿/* Copyright (c) 2011 Chris Pietschmann (http://pietschsoft.com)
 * All rights reserved
 *
 * TODO:
 * - consider removing IE8 and earlier support, since it doesn't render fast enough
 * --- Or, could add a custom renderer API to allow for different rendering styles (DIV in IE8- and Canvas in newer browsers)
*/
(function (window) {
    var CanvasMap = window.CanvasMap = function (elem, options) {
        elem.CanvasMap = elem.CanvasMap || new CanvasMap.fn.init(elem, options);
        return elem.CanvasMap;
    };
    CanvasMap.fn = CanvasMap.prototype = {
        init: function (elem, options) {
            options = options || {};

            this._elem = elem;

            var canvas = this._canvas = document.createElement('canvas');
            elem.appendChild(canvas);
            if (window.G_vmlCanvasManager) { window.G_vmlCanvasManager.initElement(canvas); }
            this._2dcontext = canvas.getContext('2d');

            this._eventHandlers = {};


            this._zoom = options.zoom || 1;
            this._center = options.center || { latitude: 0, longitude: 0 };

            this._tileLayers = [];
            if (options.tileLayers) {
                for (var itl = 0; itl < options.tileLayers.length; itl++) {
                    this._tileLayers.push(options.tileLayers[itl]);
                }
            }

            this._shapeLayers = [];
            if (options.shapeLayers) {
                for (var isl = 0; isl < options.shapeLayers.length; isl++) {
                    this._shapeLayers.push(options.shapeLayers[isl]);
                }
            }

            var self = this;

            this._redrawInterval = window.setInterval(function () {
                self.drawFrame();
            }, 10);



            // Attach Event Handlers
            var isleftmousedown = false;
            var prevmouseposition = null;

            var elemresizehandler = function () {
                var elemSize = getElementSize(self._elem);
                self._canvas.width = elemSize.width - 2;
                self._canvas.height = elemSize.height - 2;
            };
            addEventListener(elem, "resize", elemresizehandler);
            addEventListener(window, "resize", elemresizehandler);
            elemresizehandler();


            (function (name) {
                for (var n in name) {
                    addEventListener(elem, n, function (evt) {
                        evt = evt || window.event;
                        self.raise(name, evt);
                    });
                }
            })(['mouseover', 'click', 'keyup']);

            var mousemoveHandler = function (evt) {
                evt = evt || window.event;
                if (isleftmousedown) {
                    self.offsetCenterByPixels({ x: evt.offsetX - prevmouseposition.x, y: evt.offsetY - prevmouseposition.y });
                }
                prevmouseposition = { x: evt.offsetX, y: evt.offsetY };

                evt.location = self.pixelToLocation({ x: evt.offsetX, y: evt.offsetY });
                self.raise('mousemove', evt);
            };
            var dblclickHandler = function (evt) {
                evt = evt || window.event;
                if ((evt.which || evt.button) === 1) { // Left button only
                    var loc = self.pixelToLocation({ x: evt.offsetX, y: evt.offsetY });
                    self.zoom(self.zoom() + 1).center(loc);
                }
                self.raise('dblclick', evt);
            };


            if (window.navigator.msPointerEnabled) {
                //alert('Touch Enabled');
                //http://msdn.microsoft.com/en-us/ie/hh272903#_DOMTouch
                addEventListener(canvas, "MSPointerDown", function () {
                    isleftmousedown = true;
                });
                addEventListener(canvas, "MSPointerUp", function () {
                    isleftmousedown = false;
                });
                addEventListener(canvas, "MSPointerMove", mousemoveHandler);
                addEventListener(canvas, "MSGestureInit", function (e) { e.preventManipulation(); });
            } else {
                addEventListener(elem, "mousedown", function (evt) {
                    evt = evt || window.event;
                    if ((evt.which || evt.button) === 1) {
                        isleftmousedown = true;
                    }
                    self.raise('mousedown', evt);
                });
                addEventListener(elem, "mouseup", function (evt) {
                    evt = evt || window.event;
                    isleftmousedown = false;
                    self.raise('mouseup', evt);
                });
                addEventListener(elem, "mousemove", mousemoveHandler);
            }

            addEventListener(elem, "dblclick", dblclickHandler);

            addEventListener(elem, "mouseout", function (evt) {
                evt = evt || window.event;
                isleftmousedown = false;
                self.raise('mouseout', evt);
            });
            addEventListener(elem, "mousewheel", function (evt) {
                evt = evt || window.event;
                // http://www.switchonthecode.com/tutorials/javascript-tutorial-the-scroll-wheel
                var wheelData = evt.wheelDelta ? evt.wheelDelta / 120 : evt.detail;

                var loc = self.pixelToLocation({ x: evt.offsetX, y: evt.offsetY });
                self.zoom(self.zoom() + wheelData).center(loc);

                self.raise('mousewheel', evt);
            });
            addEventListener(elem, "keypress", function (evt) {
                evt = evt || window.event;
                self.raise('keypress', evt);
            });
            addEventListener(elem, "keydown", function (evt) {
                evt = evt || window.event;
                var keyCode = evt.keyCode || evt.which;
                if (keyCode === 38) {
                    //UP
                    self.offsetCenterByPixels({ x: 0, y: 15 });
                } else if (keyCode === 40) {
                    // DOWN
                    self.offsetCenterByPixels({ x: 0, y: -15 });
                } else if (keyCode === 39) {
                    // RIGHT
                    self.offsetCenterByPixels({ x: -15, y: 0 });
                } else if (keyCode == 37) {
                    // LEFT
                    self.offsetCenterByPixels({ x: 15, y: 0 });
                } else if (keyCode === 187) {
                    // PLUS
                    self.zoom(self.zoom() + 1);
                } else if (keyCode === 189) {
                    // MINUS
                    self.zoom(self.zoom() - 1);
                }

                self.raise('keydown', evt);
            });
        },
        zoom: function (v) {
            if (v !== undefined) {
                if (v > 19) { v = 19; }
                if (v < 0) { v = 0; }
                this._zoom = v;
                return this;
            }
            return this._zoom;
        },
        center: function (v) {
            if (v !== undefined) {
                this._center = v;
                return this;
            }
            return this._center;
        },
        tileLayers: function (v) {
            if (v !== undefined) {
                this._tileLayers = v;
                return this;
            }
            return this._tileLayers;
        },

        bind: function (name, f) {
            if (name.substr(0, 2) === 'on') {
                name = name.substr(2);
            }
            if (!this._eventHandlers[name]) {
                this._eventHandlers[name] = [];
            }
            this._eventHandlers[name].push(f);
            return this;
        },
        unbind: function (name, f) {
            if (name.substr(0, 2) === 'on') {
                name = name.substr(2);
            }
            if (this._eventHandlers[name]) {
                if (f === undefined) {
                    this._eventHandlers[name] = [];
                } else {
                    for (var i = 0; i < this._eventHandlers[name].length; i++) {
                        if (this._eventHandlers[name][i] === f) {
                            this._eventHandlers[name].splice(i);
                            break;
                        }
                    }
                }
            }
            return this;
        },
        raise: function (name, evt) {
            if (name.substr(0, 2) === 'on') {
                name = name.substr(2);
            }
            if (this._eventHandlers[name]) {
                for (var i = 0; i < this._eventHandlers[name].length; i++) {
                    this._eventHandlers[name][i].call(this, evt);
                }
            }
            return this;
        },

        offsetCenterByPixels: function (p) {
            var z = this.zoom(),
                centerPixel = TileSystem.locationToPixel(this.center(), z);
            this.center(TileSystem.pixelToLocation({
                x: centerPixel.x - p.x,
                y: centerPixel.y - p.y
            }, z));
        },
        pixelToLocation: function (p) {
            var z = this.zoom(),
                        elemSize = getElementSize(this._elem),
                        centerPixel = TileSystem.locationToPixel(this.center(), z),
                        newCenterPixel = {
                            x: centerPixel.x - (elemSize.width / 2) + p.x,
                            y: centerPixel.y - (elemSize.height / 2) + p.y
                        },
                        loc = TileSystem.pixelToLocation(newCenterPixel, z);
            return loc;
        },
        locationToPixel: function (loc) {
            var topleft = TileSystem.locationToPixel(this.pixelToLocation({ x: 0, y: 0 })),
                        p = TileSystem.locationToPixel(loc);
            return {
                x: p.x - topleft.x,
                y: p.y - topleft.y
            };
        },
        mapview: function () {
            var topleft = this.pixelToLocation({ x: 0, y: 0 }),
                elemSize = getElementSize(this._elem),
                bottomright = this.pixelToLocation({ x: elemSize.width, y: elemSize.height });
            return {
                north: topleft.latitude,
                south: bottomright.latitude,
                east: bottomright.longitude,
                west: topleft.longitude
            }
        },


        drawFrame: function () {
            //            if (!this._drawFrameHasMapChanged()){
            //                return;
            //            }

            var elemSize = getElementSize(this._elem);
            this._2dcontext.fillStyle = 'rgb(255,255,255)';
            this._2dcontext.fillRect(0, 0, elemSize.width, elemSize.height); // clear canvas

            this.drawTileLayers();
            this.drawShapeLayers();
        },

        //        _drawFrameHasMapChanged: function () {
        //            var prev = this._drawFrameHasMapChangedData,
        //                retVal = false,
        //                z = this.zoom(),
        //                centerPixel = TileSystem.locationToPixel(this.center(), z),
        //                elemSize = getElementSize(this._elem);

        //            if(!prev) {
        //                retVal = true;
        //            } else {
        //                if (z != prev.zoom
        //                || centerPixel.x != prev.centerPixel.x || centerPixel.y != prev.centerPixel.y
        //                || elemSize.width != prev.elemSize.width || elemSize.height != prev.elemSize.height
        //                ) {
        //                    retVal = true;
        //                }
        //            }
        //            this._drawFrameHasMapChangedData = {
        //                zoom: z,
        //                centerPixel: centerPixel,
        //                elemSize: elemSize,
        //            };            
        //            return retVal;
        //        },
        drawShapeLayers: function () {
            var mapview = this.mapview();
            for (var l = 0; l < this._shapeLayers.length; l++) {
                for (var s = 0; s < this._shapeLayers[l].length; s++) {
                    if (this._shapeLayers[l][s].latitude <= mapview.north && this._shapeLayers[l][s].latitude >= mapview.south
                    && this._shapeLayers[l][s].longitude <= mapview.east && this._shapeLayers[l][s].longitude >= mapview.west) {
                        this.drawShape(this._shapeLayers[l][s]);
                    }
                }
            }
        },
        drawShape: function (shape) {
            var pixel = TileSystem.locationToPixel(shape, this.zoom()),
                centerPixel = TileSystem.locationToPixel(this.center(), this.zoom()),
                elemSize = getElementSize(this._elem),
                drawOffsetPixel = {
                    x: elemSize.width / 2,
                    y: elemSize.height / 2
                };
            drawImageToCanvas2dContext(this, shape.url,
                    drawOffsetPixel.x + pixel.x - centerPixel.x,
                    drawOffsetPixel.y + pixel.y - centerPixel.y,
                    shape.width, shape.height);
        },
        drawTileLayers: function () {
            var z = this.zoom(),
                centerPixel = TileSystem.locationToPixel(this.center(), z),
                elemSize = getElementSize(this._elem),
                centerTile = TileSystem.pixelToTile(centerPixel),
                drawOffsetPixel = {
                    x: elemSize.width / 2,
                    y: elemSize.height / 2
                },
                minDisplayPixel = {
                    x: drawOffsetPixel.x > centerPixel.x ? 0 : centerPixel.x - drawOffsetPixel.x,
                    y: drawOffsetPixel.y > centerPixel.y ? 0 : centerPixel.y - drawOffsetPixel.y
                },
                topleftTile = TileSystem.pixelToTile({ x: minDisplayPixel.x, y: minDisplayPixel.y }),
                bottomrightTile = {
                    x: topleftTile.x + (elemSize.width / 256),
                    y: topleftTile.y + (elemSize.height / 256)
                };

            for (var tl = 0; tl < this._tileLayers.length; tl++) {
                for (var x = Math.floor(topleftTile.x); x <= bottomrightTile.x; x++) {
                    for (var y = Math.floor(topleftTile.y); y <= bottomrightTile.y; y++) {
                        var imageUrl = this._tileLayers[tl].getTileUrl(x, y, z);
                        drawImageToCanvas2dContext(this, imageUrl,
                                drawOffsetPixel.x - (centerTile.x - x) * (256 - 1),
                                drawOffsetPixel.y - (centerTile.y - y) * (256 - 1)
                                );
                    }
                }
            }
        }
    };
    CanvasMap.fn.init.prototype = CanvasMap.fn;

    function clip(n, min, max) {
        return Math.min(Math.max(n, min), max);
    }

    var TileSystem = CanvasMap.TileSystem = {
        /*
        TileSystem Reference: http://msdn.microsoft.com/en-us/library/bb259689.aspx
        */
        earthRadius: 6378137,
        minLat: -85.05112878,
        maxLat: 85.05112878,
        minLng: -180,
        maxLng: 180,
        mapSize: function (levelOfDetail) {
            return 256 << levelOfDetail;
        },
        /*
        mapTileSize: function (levelOfDetail) {
        // return the number of tiles across for this zoom / levelOfDetail
        return Math.pow(2, levelOfDetail);
        },
        */
        groundResolution: function (lat, levelOfDetail) {
            lat = clip(lat, TileSystem.minLat, TileSystem.maxLat);
            return Math.cos(latitude * Math.PI / 180) * 2 * Math.PI * TileSystem.earthRadius / TileSystem.mapSize(levelOfDetail);
        },
        mapScale: function (lat, levelOfDetail, screenDpi) {
            return TileSystem.groundResolution(lat, levelOfDetail) * screenDpi / 0.0254;
        },
        locationToPixel: function (loc, levelOfDetail) {
            //LatLongToPixelXY
            var lat = clip(loc.latitude, TileSystem.minLat, TileSystem.maxLat),
                lng = clip(loc.longitude, TileSystem.minLng, TileSystem.maxLng),

                x = (lng + 180) / 360,
                sinLat = Math.sin(lat * Math.PI / 180),
                y = 0.5 - Math.log((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI),
                mapSize = TileSystem.mapSize(levelOfDetail);
            return {
                x: clip(x * mapSize, 0, mapSize - 1),
                y: clip(y * mapSize, 0, mapSize - 1)
            };
        },
        pixelToLocation: function (p, levelOfDetail) {
            //PixelXYToLatLong
            var mapSize = TileSystem.mapSize(levelOfDetail),
                x = (clip(p.x, 0, mapSize - 1) / mapSize) - 0.5,
                y = 0.5 - (clip(p.y, 0, mapSize - 1) / mapSize);
            return {
                latitude: 90 - 360 * Math.atan(Math.exp(-y * 2 * Math.PI)) / Math.PI,
                longitude: 360 * x
            };
        },
        pixelToTile: function (p) {
            //PixelXYToTileXY
            return {
                x: p.x / 256,
                y: p.y / 256
            };
        },
        tileToPixel: function (t) {
            //TileXYToPixelXY
            return {
                x: t.x * 256,
                y: t.y * 256
            };
        },
        tileToQuadKey: function (t, levelOfDetail) {
            //TileXYToQuadKey
            var quadKey = [];
            for (var i = levelOfDetail; i > 0; i--) {
                var digit = '0',
                    mask = 1 << (i - 1);
                if ((t.x & mask) != 0) {
                    digit++;
                }
                if ((t.y & mask) != 0) {
                    digit++;
                    digit++;
                }
                quadKey.push(digit);
            }
            return quadKey.join('');
        },
        quadKeyToTile: function (quadKey) {
            //QuadKeyToTileXY
            var tileX = 0, tileY = 0;
            levelOfDetail = quadKey.length;
            for (var i = levelOfDetail; i > 0; i++) {
                var mask = 1 << (i - 1);
                switch (quadKey[levelOfDetail - i]) {
                    case '0':
                        break;
                    case '1':
                        tileX != mask;
                        break;
                    case '2':
                        tileY |= mask;
                        break;
                    case '3':
                        tileX |= mask;
                        tileY |= mask;
                        break;
                    default:
                        throw "Invalid QuadKey digit sequence.";
                }
            }
            return {
                x: tileX,
                y: tileY
            };
        }
    };

    var TileProviders = window.TileProviders = {};
    TileProviders.OSM = function () { };
    TileProviders.OSM.prototype = {
        getTileUrl: function (x, y, z) {
            return "http://b.tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png";
        }
    };
    TileProviders.GoogleMaps = function () { };
    TileProviders.GoogleMaps.prototype = {
        getTileUrl: function (x, y, z) {
            return "http://mt.google.com/vt/lyrs=m@131&hl=en&x=" + x + "&y=" + y + "&z=" + z;
        }
    };
    TileProviders.BingMaps = function () { };
    TileProviders.BingMaps.prototype = {
        getTileUrl: function (x, y, z) {
            return "http://ecn.t1.tiles.virtualearth.net/tiles/r" + TileSystem.tileToQuadKey({ x: x, y: y }, z) + ".png?g=790&mkt=en-us";
        }
    };


    var imageCacheImages = {};
    var imageCacheImageIDs = []
    function cacheImage(url, img) {
        if (img === undefined) {
            return imageCacheImages[url];
        } else {
            if (imageCacheImageIDs.length >= 25) {
                delete imageCacheImages[imageCacheImageIDs.splice(0)];
            }
            imageCacheImageIDs.push(url);
            imageCacheImages[url] = img;
        }
    }
    function drawImageToCanvas2dContext(map, imageUrl, dx, dy, width, height) {
        var cache = cacheImage(imageUrl);

        var img = cache || new Image();
        var loaded = function () {
            drawLoadedImageToCanvas2dContext(map, img, dx, dy, width, height);
            img.removeEventListener('load', loaded);
        };
        //img.onload
        addEventListener(img, 'load', loaded);
        if (!cache) {
            img.src = imageUrl;
            cacheImage(imageUrl, img);
        } else {
            try {
                loaded();
            } catch (ex) { }
        }
    }

    function drawLoadedImageToCanvas2dContext(map, img, dx, dy, width, height) {
        var context = map._2dcontext;
        if (width === undefined && height === undefined) {
            context.drawImage(img, dx, dy);
        } else {
            context.drawImage(img, 0, 0, img.width, img.height, dx, dy, width, height);
        }
    }

    function getElementSize(elem) {
        return {
            width: elem.offsetWidth,
            height: elem.offsetHeight
        };
    }

    function addEventListener(e, n, f) {
        if (e.addEventListener) {
            e.addEventListener(n, f);
        } else {
            // IE 8 and earlier
            e.attachEvent('on' + n, f);
        }
    }

    function removeEventListener(e, n, f) {
        if (e.removeEventListener) {
            e.removeEventListener(n, f);
        } else {
            // IE 8 and earlier
            e.detachEvent('on' + n, f);
        }
    }
})(window);