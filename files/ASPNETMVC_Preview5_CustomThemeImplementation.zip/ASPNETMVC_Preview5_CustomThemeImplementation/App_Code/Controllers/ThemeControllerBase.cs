﻿public class ThemeControllerBase : System.Web.Mvc.Controller
{
    protected override void Execute(System.Web.Routing.RequestContext requestContext)
    {
        //requestContext.HttpContext.Items["themeName"] = "Red";
        requestContext.HttpContext.Items["themeName"] = requestContext.HttpContext.Request.QueryString["theme"];

        base.Execute(requestContext);
    }
}