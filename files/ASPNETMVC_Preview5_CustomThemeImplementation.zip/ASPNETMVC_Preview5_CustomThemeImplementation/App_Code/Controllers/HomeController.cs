﻿using System.Web.Mvc;

namespace MvcWebsite.Controllers
{
    [HandleError]
    public class HomeController : ThemeControllerBase
    {
        public ActionResult Index()
        {
            ViewData["Title"] = "Home Page";
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            ViewData["Title"] = "About Page";

            return View();
        }
    }
}
