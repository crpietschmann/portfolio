This code example goes along with the below article:

Custom Themes in ASP.NET MVC Updated for Preview 5
by Chris Pietschmann
http://pietschsoft.com/post/2008/08/Custom-Themes-in-ASPNET-MVC-Updated-for-Preview-5.aspx