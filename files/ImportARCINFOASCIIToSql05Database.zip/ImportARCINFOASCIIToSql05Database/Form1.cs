﻿// Copyright (c) 2007 Chris Pietschmann (http://pietschsoft.com)
// Originally Posted Here:
// http://pietschsoft.com/post/2008/06/Plot-ZipCode-Boundaries-on-a-Map-Part-2-Import-Zip-Code-US-Census-ZCTA-Data-Into-A-Database.aspx

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace ImportARCINFOASCIIToSql05Database
{
    public partial class Form1 : Form
    {
        string connectionString = "data source=.\\SQLEXPRESS;Integrated Security=SSPI;database=ZipCodeBoundaries;";
        SqlConnection con;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fd = new FolderBrowserDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {

                string[] files = Directory.GetFiles(fd.SelectedPath);


                progressBar1.Maximum = files.Length + 1;
                progressBar1.Minimum = 0;
                progressBar1.Value = 0;

                Dictionary<string, ZipCode> zipCodes;

                con = new SqlConnection(this.connectionString);
                con.Open();

                foreach (string filepath in files)
                {
                    if (filepath.ToLowerInvariant().EndsWith("a.dat.csv"))
                    {
                        // Import all ZipCode
                        lblStatus.Text = "Importing " + filepath.Substring(filepath.LastIndexOf("\\"));
                        zipCodes = this.ImportZipCodesFromCSV(filepath);

                        Application.DoEvents();
                        lblStatus.Text = "Importing " + filepath.Replace("a.dat.csv", ".dat.csv").Substring(filepath.LastIndexOf("\\"));
                        progressBar1.Value++;

                        // Import all ZipCode Boundaries, pass this method the list of ZipCode in the file so the GUIDs can be used when saving them to the database
                        this.ImportZipCodeBoundariesFromCSV(filepath.Replace("a.dat.csv", ".dat.csv"), zipCodes);

                        progressBar1.Value++;
                        Application.DoEvents();
                    }
                }

                con.Close();
                con.Dispose();

                lblStatus.Text = "Import Complete";
            }
        }

        private Dictionary<string, ZipCode> ImportZipCodesFromCSV(string filepath)
        {
            Dictionary<string, ZipCode> col = new Dictionary<string, ZipCode>();

            // Open CSV File
            FileStream f = new FileStream(filepath, FileMode.Open);
            StreamReader reader = new StreamReader(f);
            string strLine = string.Empty;
            string[] fields;

            // Skip first line of file, since it's the column names
            reader.ReadLine();

            while (!reader.EndOfStream)
            {
                // Read ZipCode record from file
                strLine = reader.ReadLine();

                // Split the record fields into an array
                fields = strLine.Split(',');

                // Make sure "NAME" field in CSV File has a Value, some files start with a blank record
                if (!string.IsNullOrEmpty(fields[2].Trim()))
                {
                    // Populate new ZipCode object with record from file
                    ZipCode z = new ZipCode();
                    z.ZipID = Guid.NewGuid();
                    z.Zip = fields[2];

                    // Add ZipCode to Database
                    SqlCommand cmd = new SqlCommand("INSERT ZipCode (ID,ZipCode) VALUES (@ID,@ZipCode)", con);
                    cmd.Parameters.AddWithValue("@ID", z.ZipID.ToString());
                    cmd.Parameters.AddWithValue("@ZipCode", z.Zip);
                    cmd.ExecuteNonQuery();

                    // Add ZipCode to collection, using the "ZipID" field
                    // from the file as the Dictionary Key
                    col.Add(fields[0], z);
                }
            }

            // Close CSV File
            reader.Close();
            reader.Dispose();
            f.Dispose();

            return col;
        }

        private void ImportZipCodeBoundariesFromCSV(string filepath, Dictionary<string, ZipCode> zipCodes)
        {
            // Open CSV File
            FileStream f = new FileStream(filepath, FileMode.Open);
            StreamReader reader = new StreamReader(f);
            string[] fields;
            string strLine = string.Empty;

            // Skip first line of file, since it's the column names
            reader.ReadLine();

            while (!reader.EndOfStream)
            {
                // Read ZipCode record from file
                strLine = reader.ReadLine();

                // Split the record fields into an array
                fields = strLine.Split(',');

                // Import into Database
                SqlCommand cmd = new SqlCommand("INSERT ZipCodeBoundary (ID,ZipCodeID,IslandID,Latitude,Longitude,SortOrder) VALUES (@ID,@ZipCodeID,@IslandID,@Latitude,@Longitude,@SortOrder)", con);
                cmd.Parameters.AddWithValue("@ID", Guid.NewGuid());
                cmd.Parameters.AddWithValue("@ZipCodeID", zipCodes[fields[0]].ZipID);
                cmd.Parameters.AddWithValue("@IslandID", (string.IsNullOrEmpty(fields[1]) ? 0 : int.Parse(fields[1])));
                cmd.Parameters.AddWithValue("@Latitude", double.Parse(fields[2]));
                cmd.Parameters.AddWithValue("@Longitude", double.Parse(fields[3]));
                cmd.Parameters.AddWithValue("@SortOrder", int.Parse(fields[4]));
                cmd.ExecuteNonQuery();
            }

            // Close CSV File
            reader.Close();
            reader.Dispose();
            f.Dispose();
        }
    }
}
