﻿// Copyright (c) 2007 Chris Pietschmann (http://pietschsoft.com)
// Originally Posted Here:
// http://pietschsoft.com/post/2008/06/Plot-ZipCode-Boundaries-on-a-Map-Part-2-Import-Zip-Code-US-Census-ZCTA-Data-Into-A-Database.aspx

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImportARCINFOASCIIToSql05Database
{
    public class ZipCode
    {
        public Guid ZipID { get; set; }
        public string Zip { get; set; }
    }
}
