﻿// Copyright (c) Chris Pietschmann 2008. All rights reserved.
// This work is licensed under a Creative Commons Attribution 3.0 United States License (http://creativecommons.org/licenses/by/3.0/us/)
// Originally posted at: http://pietschsoft.com/post/2008/05/ASPNET_35_Create_AJAX_Extender_Controls_using_the_ExtenderControl_base_class.aspx
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI;

public class ExtenderControlBase : ExtenderControl
{
    protected override IEnumerable<ScriptDescriptor> GetScriptDescriptors(Control targetControl)
    {
        ScriptControlDescriptor descriptor = new ScriptControlDescriptor(this.GetType().FullName, targetControl.ClientID);

        descriptor.AddProperty("id", this.ClientID);

        // Add all the ExtenderControls Client-Side Object Properties
        PropertyDescriptorCollection props = TypeDescriptor.GetProperties(this);
        foreach (PropertyDescriptor prop in props)
        {
            ExtenderControlPropertyAttribute propAttr = prop.Attributes[typeof(ExtenderControlPropertyAttribute)] as ExtenderControlPropertyAttribute;
            if (propAttr != null)
            {
                object value = prop.GetValue(this);
                string name = (propAttr.Name != null) ? propAttr.Name : prop.Name;
                if (value != null)
                {
                    descriptor.AddProperty(name, value);
                }
            }
        }

        yield return descriptor;
    }

    protected override IEnumerable<ScriptReference> GetScriptReferences()
    {
        // Add all the ExtenderControls Client-Side JavaScript References
        object[] scriptReferences = Attribute.GetCustomAttributes(this.GetType(), typeof(ScriptReferenceAttribute), false);
        foreach (ScriptReferenceAttribute r in scriptReferences)
        {
            yield return r.GetScriptReference();
        }
    }
}

[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public class ExtenderControlPropertyAttribute : Attribute
{
    public ExtenderControlPropertyAttribute() { }

    public ExtenderControlPropertyAttribute(string name)
    {
        this.Name = name;
    }

    public string Name { get; set; }
}

[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
public class ScriptReferenceAttribute : Attribute
{
    public ScriptReferenceAttribute(string path)
    {
        this.Path = path;
    }

    public ScriptReferenceAttribute(string name, string assembly)
    {
        this.Name = name;
        this.Assembly = assembly;
    }

    private string _path = null;
    public string Path
    {
        get { return _path; }
        set { _path = value; }
    }

    private string _name = null;
    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    private string _assembly = null;
    public string Assembly
    {
        get { return _assembly; }
        set { _assembly = value; }
    }

    public ScriptReference GetScriptReference()
    {
        ScriptReference r = null;

        if (this.Path == null)
        {
            r = new ScriptReference(this.Name, this.Assembly);
        }
        else
        {
            r = new ScriptReference(this.Path);
        }

        return r;
    }
}

