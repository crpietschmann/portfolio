﻿/// <reference name="MicrosoftAjax.js" />
// Copyright (c) Chris Pietschmann 2008. All rights reserved.
// This work is licensed under a Creative Commons Attribution 3.0 United States License (http://creativecommons.org/licenses/by/3.0/us/)
// Originally posted at: http://pietschsoft.com/post/2008/05/ASPNET_35_Create_AJAX_Extender_Controls_using_the_ExtenderControl_base_class.aspx
Type.registerNamespace("CustomExtenderControl");

CustomExtenderControl.FocusExtender = function(element) {
    CustomExtenderControl.FocusExtender.initializeBase(this, [element]);
    this._HighlightCssClass = null;
    this._NoHighlightCssClass = null;
    
    this._focusHandler = Function.createDelegate(this, this._onFocus);
    this._blurHandler = Function.createDelegate(this, this._onBlur);
};

CustomExtenderControl.FocusExtender.prototype = {
    initialize:function(){
        CustomExtenderControl.FocusExtender.callBaseMethod(this, "initialize");
        
        var targetElement = this.get_element();
        
        $addHandler(targetElement, "focus", this._focusHandler);
        $addHandler(targetElement, "blur", this._blurHandler);        
    },
    dispose:function(){
        var targetElement = this.get_element();
        
        $removeHandler(targetElement, "focus", this._focusHandler);    
        $removeHandler(targetElement, "blur", this._blurHandler);
    
        CustomExtenderControl.FocusExtender.callBaseMethod(this, "dispose");
    },
    
    get_HighlightCssClass:function() {
        return this._HighlightCssClass;
    },
    set_HighlightCssClass:function(v) {
        this._HighlightCssClass = v;
    },
    get_NoHighlightCssClass:function() {
        return this._NoHighlightCssClass;
    },
    set_NoHighlightCssClass:function(v) {
        this._NoHighlightCssClass = v;
    },
    
    //Event Handler Methods
    _onFocus:function(eventArgs) {
        var targetElement = this.get_element();
        if (targetElement != null)
        {
            targetElement.className = this.get_HighlightCssClass();
        }
    },
    _onBlur:function(eventArgs) {
        var targetElement = this.get_element();
        if (targetElement != null)
        {
            targetElement.className = this.get_NoHighlightCssClass();
        }
    }
};

CustomExtenderControl.FocusExtender.registerClass("CustomExtenderControl.FocusExtender", Sys.UI.Behavior);

Sys.Application.notifyScriptLoaded();