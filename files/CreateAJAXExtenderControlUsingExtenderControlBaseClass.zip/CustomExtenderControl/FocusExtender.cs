﻿// Copyright (c) Chris Pietschmann 2008. All rights reserved.
// This work is licensed under a Creative Commons Attribution 3.0 United States License (http://creativecommons.org/licenses/by/3.0/us/)
// Originally posted at: http://pietschsoft.com/post/2008/05/ASPNET_35_Create_AJAX_Extender_Controls_using_the_ExtenderControl_base_class.aspx
using System;
using System.Web.UI;

[assembly: System.Web.UI.WebResource("CustomExtenderControl.FocusExtender.js", "text/javascript")] 

namespace CustomExtenderControl
{
    [TargetControlType(typeof(Control)),
    ScriptReference("CustomExtenderControl.FocusExtender.js", "CustomExtenderControl")]
    public class FocusExtender : ExtenderControlBase
    {
        [ExtenderControlProperty]
        public string HighlightCssClass { get; set; }

        [ExtenderControlProperty]
        public string NoHighlightCssClass { get; set; }
    }
    /*
    [TargetControlType(typeof(Control))]
    public class FocusExtender : ExtenderControl
    {
        public string HighlightCssClass { get; set; }
        public string NoHighlightCssClass { get; set; }

        protected override System.Collections.Generic.IEnumerable<ScriptDescriptor> GetScriptDescriptors(Control targetControl)
        {
            ScriptBehaviorDescriptor descriptor = new ScriptBehaviorDescriptor(this.GetType().FullName, targetControl.ClientID);

            descriptor.AddProperty("id", this.ClientID);

            descriptor.AddProperty("HighlightCssClass", this.HighlightCssClass);
            descriptor.AddProperty("NoHighlightCssClass", this.NoHighlightCssClass);

            yield return descriptor;
        }

        protected override System.Collections.Generic.IEnumerable<ScriptReference> GetScriptReferences()
        {
            yield return new ScriptReference("CustomExtenderControl.FocusExtender.js", "CustomExtenderControl");
        }
    }
    */
}
