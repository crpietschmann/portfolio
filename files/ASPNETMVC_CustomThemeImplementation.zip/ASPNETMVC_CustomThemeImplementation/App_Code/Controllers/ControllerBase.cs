﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

/// <summary>
/// Summary description for ControllerBase
/// </summary>
public class ControllerBase : System.Web.Mvc.Controller
{
    protected override void Execute(ControllerContext controllerContext)
    {

        //controllerContext.HttpContext.Items["themeName"] = "Red";
        controllerContext.HttpContext.Items["themeName"] = controllerContext.HttpContext.Request.QueryString["theme"];

        base.Execute(controllerContext);
    }
}
