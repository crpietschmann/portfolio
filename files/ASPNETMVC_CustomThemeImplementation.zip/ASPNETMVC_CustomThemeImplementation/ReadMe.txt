This code example goes along with the below article:

How To Setup Custom Theme Support In ASP.NET MVC using a Custom ViewEngine
by Chris Pietschmann
http://pietschsoft.com/post/2008/08/How-To-Setup-Custom-Theme-Support-In-ASPNET-MVC-using-a-Custom-ViewEngine.aspx