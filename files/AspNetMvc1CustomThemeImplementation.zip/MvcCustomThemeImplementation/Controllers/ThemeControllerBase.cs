﻿using System.Web.Mvc;

// This code was originally posted at:
// http://pietschsoft.com/post.aspx?id=237305ef-7b41-45f4-af3b-d7b1b116e78b

namespace MvcApplication1.Controllers
{
    public abstract class ThemeControllerBase : Controller
    {
        protected override void Execute(System.Web.Routing.RequestContext requestContext)
        {
            // Add code here to set the Theme based on your database or some other storage
            requestContext.HttpContext.Items["themeName"] = "Red";


            
            // Allow the Theme to be overriden via the querystring
            // If a Theme Name is Passed in the querystring then use it and override the previously set Theme Name
            // http://localhost/Default.aspx?theme=Red
            var previewTheme = requestContext.HttpContext.Request.QueryString["theme"];
            if (!string.IsNullOrEmpty(previewTheme))
            {
                requestContext.HttpContext.Items["themeName"] = previewTheme;
            }

            base.Execute(requestContext);
        }
    }
}
