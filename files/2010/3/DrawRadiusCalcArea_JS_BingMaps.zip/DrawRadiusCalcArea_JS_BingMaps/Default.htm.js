﻿var map = null;

function LoadMap()
{
    // Load the Map
    map = new VEMap("myMap");
    map.LoadMap();
    
    // Attach our onclick map event handler
    map.AttachEvent("onclick", Map_Click);
}

// The Map onclick event handler
function Map_Click(eventArgs)
{
    var clickedLatLong = eventArgs.latlong;
    if (map.GetMapMode() == VEMapMode.Mode2D)
    {
        // In 2D Mode the eventArgs.latlong property doesn't contain the lat/long point that was clicked.
        // So we must figure it out using the x and y coordinates of the point on the map that was clicked.
        clickedLatLong = map.PixelToLatLong(new VEPixel(eventArgs.mapX, eventArgs.mapY));
    }
    
    // When the user Right-Clicks, Draw the Polygon
    if (eventArgs.rightMouseButton)
    {
        var units = GeoCodeCalc.EarthRadiusInMiles;
        var unitName = "Miles"
        if (document.getElementById("rdKilometers").checked)
        {
            units = GeoCodeCalc.EarthRadiusInKilometers;
            unitName = "Kilometers"
        }
        
        var radius = parseFloat(document.getElementById("txtRadius").value);
        if (isNaN(radius))
        {
            alert("The radius must be a number.");
        }
        else
        {
            var circle = CreateCircle(clickedLatLong, radius, units);

	    // Calculate Area of Circle and display it within the Pushpins Title
            var area = Math.PI * (radius * radius);
            circle.SetTitle("Area in " + unitName + ": " + area);


            map.AddShape(circle);
        }
    }
}

function btnClearMap_Click()
{
    // Clear all points plotted
    map.DeleteAllShapes();
}