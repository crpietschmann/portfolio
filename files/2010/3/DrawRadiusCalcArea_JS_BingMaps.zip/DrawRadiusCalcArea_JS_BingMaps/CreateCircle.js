﻿/* *************************************************************************** */
/* Written Chris Pietschmann (http://pietschsoft.com)                          */
/* This code is dependant on the GeoCodeCalc class found here:                 */
/* http://pietschsoft.com/Blog/Post.aspx?PostID=1453                           */
/* *************************************************************************** */
/* This mathimatical code is a modified version of the code originally posted  */
/* at the following location:                                                 */
/* http://viavirtualearth.com/Wiki/Draw+a+circle.ashx                          */
/* *************************************************************************** */

if (GeoCodeCalc == undefined) var GeoCodeCalc = {}
GeoCodeCalc.ToDegrees = function(radians){
    return radians * 180 / Math.PI;
};

function CreateCircle(loc, radius, units)
{    
    var earthRadius = parseFloat(units);
    var lat = GeoCodeCalc.ToRadian(loc.Latitude); //radians
    var lon = GeoCodeCalc.ToRadian(loc.Longitude); //radians
    var d = parseFloat(radius) / earthRadius;  // d = angular distance covered on earth's surface
    var locs = new Array();
    for (x = 0; x <= 360; x++) 
    { 
        var p2 = new VELatLong(0,0)            
        brng = GeoCodeCalc.ToRadian(x); //radians
        
        var latRadians = Math.asin(Math.sin(lat) * Math.cos(d) + Math.cos(lat) * Math.sin(d) * Math.cos(brng));
        var lngRadians = lon + Math.atan2(Math.sin(brng) * Math.sin(d) * Math.cos(lat), Math.cos(d) - Math.sin(lat) * Math.sin(latRadians));
        
        locs.push(new VELatLong(GeoCodeCalc.ToDegrees(latRadians), GeoCodeCalc.ToDegrees(lngRadians)));
    }
    
   return new VEShape(VEShapeType.Polyline, locs); 
}