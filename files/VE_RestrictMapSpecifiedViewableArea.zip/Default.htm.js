/* ************************************************************************* */
/* Copyright (c) 2008 Chris Pietschmann. All rights reserved                 */
/* This code was originally posted here:                                     */
/* http://pietschsoft.com/post.aspx?id=d5025e10-f1bf-4b56-9eae-71095fe256a8  */
/* ************************************************************************* */
var map = null;
var mapOriginalCenterPoint = null;
var mapStartPanPoint = null;

var mapRestrictionDistance = 100;
var mapRestrictionUnit = GeoCodeCalc.EarthRadiusInMiles;
var mapRestrictionZoomLevel = 7;

function GetMap()
{
    map = new VEMap('myMap');
    map.LoadMap();

    //Set the maps initial zoom level to be zoomed
    //out all the way to the restriction imposed
    map.SetZoomLevel(mapRestrictionZoomLevel);

    //Save the maps center point, we'll use
    //this to determine the map pan restriction
    mapOriginalCenterPoint = map.GetCenter();

    //Attach our onendpan event handler
    map.AttachEvent("onendpan", map_onendpan);

    //Attach our onstartpan event handler
    map.AttachEvent("onstartpan", map_onstartpan);

    //Attach our onendzoom event handler
    map.AttachEvent("onendzoom", map_onendzoom);


    //Plot visual reference point at center of Map
    var s = new VEShape(VEShapeType.Pushpin, map.GetCenter());
    s.SetTitle("Original Center Point");
    map.AddShape(s);

    //Plot a circle on the map for a visual reference
    //of the restricted zone
    var c = CreateCircle(map.GetCenter(), mapRestrictionDistance, mapRestrictionUnit);
    c.HideIcon();
    map.AddShape(c);


    displayCurrentLocation();
}

function map_onendzoom(e)
{
    //Check if the map is zoomed out further than
    //the set restriction
    if (e.zoomLevel < mapRestrictionZoomLevel)
    {
        //Zoom the map back in to the restricted area
        map.SetZoomLevel(mapRestrictionZoomLevel);
    }

    displayCurrentLocation();
}

function map_onstartpan(e)
{
    //Get the current map center point before panning begins
    mapStartPanPoint = map.GetCenter();
}

function map_onendpan(e)
{
    //Get total distance panned from map center
    var distance = GeoCodeCalc.CalcDistance(
	mapOriginalCenterPoint.Latitude,
	mapOriginalCenterPoint.Longitude,
	map.GetCenter().Latitude,
	map.GetCenter().Longitude,
        mapRestrictionUnit
        );

    //Check distance panned from original center point
    if (distance > mapRestrictionDistance)
    {
        //Move map back to the last point that was
        //within the desired restriction radius
        map.SetCenter(mapStartPanPoint);
    }

    displayCurrentLocation();
}

function displayCurrentLocation()
{
    //Display current Lat/Lng in page
    document.getElementById("currentLatitude").innerText = map.GetCenter().Latitude;
    document.getElementById("currentLongitude").innerText = map.GetCenter().Longitude;

    document.getElementById("currentZoom").innerText = map.GetZoomLevel();
}