/// Search Keyword Highlighter BlogEngine.NET Extension
/// Copyright 2008 Chris Pietschmann (http://pietschsoft.com)
/// This work is licensed under a Creative Commons Attribution 3.0 United States License
/// http://creativecommons.org/licenses/by/3.0/us/
///

To Use:
1) Copy SearchKeywordHighlighter.cs into the /App_Code/Extensions folder
2) Create the folder named "js" in the root of BlogEngine, and copy "se_hilite.js" to that folder
3) Copy the following CSS the CSS file in your theme:

.hilite1 { background-color: #ff0; }
.hilite2 { background-color: #f0f; }
.hilite3 { background-color: #0ff; }


For More Info on se_hilite.js:
http://scott.yang.id.au/code/se-hilite/