/// Search Keyword Highlighter BlogEngine.NET Extension
/// Copyright 2008 Chris Pietschmann (http://pietschsoft.com)
/// This work is licensed under a Creative Commons Attribution 3.0 United States License
/// http://creativecommons.org/licenses/by/3.0/us/
/// 

using System;
using BlogEngine.Core.Web.Controls;
using BlogEngine.Core;
using System.Web;

/// <summary>
/// Summary description for SearchHighlighter
/// </summary
[Extension("Add Search Engine Keyword Highlighting via se_hilite.js", "1.3.0.0", "<a href='http://pietschsoft.com'>Chris Pietschmann</a>")]
public class SearchKeywordHighlighterExtension
{
    public SearchKeywordHighlighterExtension()
	{
        BlogEngine.Core.Post.Serving += new EventHandler<BlogEngine.Core.ServingEventArgs>(ServingContent);
        BlogEngine.Core.Page.Serving += new EventHandler<BlogEngine.Core.ServingEventArgs>(ServingContent);
	}

    /// <summary>
    /// An event that handles ServingEventArgs
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void ServingContent(object sender, ServingEventArgs e)
    {
        string strUrl = BlogEngine.Core.Utils.AbsoluteWebRoot.ToString() + "js/se_hilite.js";
        e.Body += "<script type='text/javascript' src='" + strUrl + "'></script>";
    }
}