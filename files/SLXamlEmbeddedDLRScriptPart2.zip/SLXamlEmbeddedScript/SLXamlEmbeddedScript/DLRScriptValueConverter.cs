﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using Microsoft.Scripting.Hosting;
using System.Windows.Markup;

namespace SLXamlEmbeddedScript
{
    [ContentProperty("ConvertScript")]
    public class DLRScriptValueConverter : IValueConverter
    {
        public DLRScriptValueConverter()
        {
            this.Language = "IronRuby";

        }
        public string Language { get; set; }
        public string ConvertScript { get; set; }
        public string ConvertBackScript { get; set; }

        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (string.IsNullOrEmpty(this.Language))
            {
                throw new InvalidOperationException("DLRScriptValueConverter.Language property must be set");
            }
            
            if (string.IsNullOrEmpty(this.ConvertScript) && string.IsNullOrEmpty(parameter as string))
            {
                throw new InvalidOperationException("parameter or DLRScriptValueConverter.ConvertScript property must be contain a value");
            }

            if (this.Language.ToLowerInvariant() != "ironruby")
            {
                throw new InvalidOperationException(string.Format("Unsupported DLR Language ({0}). Currently only IronRuby is supported.", this.Language));
            }

            // Create Ruby ScriptEngine
            ScriptEngine engine = IronRuby.Ruby.CreateEngine();

            // Make the "value" to be converted available to the DLR
            engine.Runtime.Globals.SetVariable("ConverterValue", value);

            // Execute the script and return its result
            if (parameter != null && parameter is string)
            {
                return engine.Execute(parameter as string);
            }
            else
            {
                return engine.Execute(this.ConvertScript);
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (string.IsNullOrEmpty(this.Language))
            {
                throw new InvalidOperationException("DLRScriptValueConverter.Language property must be set");
            }

            if (string.IsNullOrEmpty(this.ConvertBackScript) && string.IsNullOrEmpty(parameter as string))
            {
                throw new InvalidOperationException("parameter or DLRScriptValueConverter.ConvertBackScript property must be contain a value");
            }

            if (this.Language.ToLowerInvariant() != "ironruby")
            {
                throw new InvalidOperationException(string.Format("Unsupported DLR Language ({0}). Currently only IronRuby is supported.", this.Language));
            }

            // Create Ruby ScriptEngine
            ScriptEngine engine = IronRuby.Ruby.CreateEngine();

            // Make the "value" to be converted available to the DLR
            engine.Runtime.Globals.SetVariable("ConverterValue", value);

            // Execute the script and return its result
            if (parameter != null && parameter is string)
            {
                return engine.Execute(parameter as string);
            }
            else
            {
                return engine.Execute(this.ConvertBackScript);
            }
        }

        #endregion
    }
}
