﻿using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;
using IronRuby;
using Microsoft.Scripting.Hosting;

namespace SLXamlEmbeddedScript
{
    public class DLRScriptUserControl : UserControl
    {
        public object Script { get; set; }

        public DLRScriptUserControl()
        {
            this.Loaded += new RoutedEventHandler(DLRScriptUserControl_Loaded);
        }

        void DLRScriptUserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // Create IronRuby Engine
            ScriptEngine engine = Ruby.CreateEngine();

            // Load necessary assemblies for event handling, etc.
            // Load System.Windows
            engine.Runtime.LoadAssembly(typeof(UserControl).Assembly);
            // Load System.Windows.Browser
            engine.Runtime.LoadAssembly(typeof(HtmlPage).Assembly);
            
            //var a = typeof(HtmlPage).Assembly.FullName;
            //engine.Runtime.LoadAssembly(Assembly.Load("System.Windows, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e"));
            //engine.Runtime.LoadAssembly(Assembly.Load("System.Windows.Browser, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e"));

            // Give IronRuby access to this control via a variable named 'Ctrl'
            engine.Runtime.Globals.SetVariable("Ctrl", this);
            
            // Execute the code
            engine.Execute(this.Script as string, engine.CreateScope());
        }
    }
}
