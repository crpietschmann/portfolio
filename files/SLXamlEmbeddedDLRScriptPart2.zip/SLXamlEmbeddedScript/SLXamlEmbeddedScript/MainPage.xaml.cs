﻿using System.Net;
using System.Windows.Controls;
using System.Windows.Markup;

namespace SLXamlEmbeddedScript
{
    public partial class MainPage : UserControl
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public MainPage()
        {
            InitializeComponent();

            this.FirstName = "Chris";
            this.LastName = "Pietschmann";

            this.Loaded += new System.Windows.RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            var client = new WebClient();
            client.DownloadStringCompleted += (s, args) => {
                // Load XAML once downloaded, and set the resulting
                // UI control to the content of the ContentPresenter
                parseXamlTest.Content = XamlReader.Load(args.Result);
            };
            // Download the XAML file
            client.DownloadStringAsync(
                new System.Uri("http://localhost:9028/DLRControl.xaml")
                );
        }
    }
}
